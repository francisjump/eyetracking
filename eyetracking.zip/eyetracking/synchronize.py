import os
import cv2
import re
import numpy as np
from scipy import spatial
import datetime
from matplotlib import pyplot as plt
import pandas as pd
from pathlib import Path
from scipy.spatial import distance

def sourceVideoToFrame_syncScreen(url, dest_path):
    vidcap = cv2.VideoCapture(url)
    success, image = vidcap.read()
    count = 0
    if not os.path.exists(dest_path):
        os.mkdir(dest_path)
    while success:
        cv2.imwrite(dest_path + "%d.jpg" % count, image)  # save frame as JPEG file
        success, image = vidcap.read()
        count += 1
        if count == 1800:
            break
    print('done')
    print('Read total frames: ', count)

def getCoordFromActualScreen(filepath):
    frame = cv2.imread(filepath+'300.jpg') 
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    # set lower and upper color limits
    lower_val = np.array([0, 75, 60])
    upper_val = np.array([20, 222, 222])
    # Threshold the HSV image
    mask = cv2.inRange(hsv, lower_val, upper_val)
    # remove noise
    kernel = np.ones((5,5),np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_GRADIENT, kernel)
    # find contours in mask
    contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    contoursAdd = []
    contoursArea = []
    for i in contours:
        M = cv2.moments(i)
        if M['m00'] != 0:
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])
            contoursAdd.append([cx, cy, M['m00']])
            contoursArea.append(M['m00'])
    if contoursArea:
        largest = max(contoursArea)
        max_index = contoursArea.index(largest)
        print ("done")
        print ("The coordinate of the first frame is shown below.")
        print (contoursAdd[max_index][0],contoursAdd[max_index][1])
        return contoursAdd[max_index][0],contoursAdd[max_index][1]

def syncStartPoint(actual_x_coord,actual_y_coord,filepath):
    filearr = os.listdir(filepath)
    filearr.sort(key=lambda f: int(re.sub('\D', '', f)))
    coord_storage = []
    index_storage = []
    for i in range(len(filearr)):
        # print('we are now finding ' + filearr[i])
        image = cv2.imread(filepath+filearr[i])
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    # set lower and upper color limits
        lower_val = np.array([0, 75, 60])
        upper_val = np.array([20, 222, 222])
        # Threshold the HSV image
        mask = cv2.inRange(hsv, lower_val, upper_val)
        # remove noise
        kernel = np.ones((5,5),np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_GRADIENT, kernel)
        # find contours in mask
        contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        contoursAdd = []
        contoursArea = []
        for j in contours:
            M = cv2.moments(j)
            if M['m00'] != 0:
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                contoursAdd.append([cx, cy, M['m00']])
                contoursArea.append(M['m00'])
        if contoursArea:
            largest = max(contoursArea)
            max_index = contoursArea.index(largest)       
            coord_storage.append((contoursAdd[max_index][0],contoursAdd[max_index][1]))
            # print(contoursAdd[max_index][0],contoursAdd[max_index][1])
            index_storage.append(i)
            if (contoursAdd[max_index][0] == actual_x_coord) and (contoursAdd[max_index][1] == actual_y_coord):
                return filearr[i]
    
    count = 0
    find_coord = set()
    for i in range(len(index_storage)):
        if (index_storage[i] >= 299) and (count == 0):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            count += 1
        if (index_storage[i] >= 599) and (count == 1):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            count += 1
        if (index_storage[i] >= 899) and (count == 2):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            count += 1
        if (index_storage[i] >= 1199) and (count == 3):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            count += 1
        if (index_storage[i] >= 1499) and (count == 4):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            count += 1
        if (index_storage[i] >= 1799) and (count == 5):
            tree = spatial.KDTree(coord_storage[:i])
            result = tree.query([(actual_x_coord,actual_y_coord)])
            find_coord.add(index_storage[result[1][0]])
            break
    print("done")
    print("The closest frame is", min(find_coord))
    return min(find_coord)

def sourceVideoToFrame_actualScreen(url, dest_path):
    vidcap = cv2.VideoCapture(url)
    success, image = vidcap.read()
    count = 0
    if not os.path.exists(dest_path):
        os.mkdir(dest_path)
    while success:
        cv2.imwrite(dest_path + "%d.jpg" % count, image)  # save frame as JPEG file
        success, image = vidcap.read()
        count += 1
    print('done')
    print('Read total frames: ', count)

def sourceVideoToFrame_finalScreen(start,url, dest_path):
    vidcap = cv2.VideoCapture(url)
    success, image = vidcap.read()
    count = 0
    if not os.path.exists(dest_path):
        os.mkdir(dest_path)
    while success:
        if ((count-start) > -1) and ((count-start) % 3 == 0):
            cv2.imwrite(dest_path + "%d.jpg" % count, image)  # save frame as JPEG file
        success, image = vidcap.read()
        count += 1
    print('done')
    print('Read total frames: ', count)

def generateSummary(video_name,black_filepath,actual_filepath):
    filearr = os.listdir(black_filepath)
    filearr_actual = os.listdir(actual_filepath)
    if (len(filearr_actual) < len(filearr)):
        max_length = len(filearr_actual)
    else:
        max_length = len(filearr)
    filearr.sort(key=lambda f: int(re.sub('\D', '', f)))
    today = datetime.datetime.now()
    summary = pd.DataFrame()
    count = 0
    file_index = 0
    count_distance = 0
    for j in range(max_length):
        print(j, filearr[j])
        coordinate = pd.DataFrame()
        frame = cv2.imread(black_filepath+filearr[j])
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
         # set lower and upper color limits
        lower_val = np.array([0, 75, 60])
        upper_val = np.array([20, 222, 222])
            # Threshold the HSV image
        mask = cv2.inRange(hsv, lower_val, upper_val)
            # remove noise
        kernel = np.ones((5,5),np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_GRADIENT, kernel)
            # find contours in mask
        contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            # Find the rotated rectangles and ellipses for each contour
        minRect = [None] * len(contours)
        minEllipse = [None] * len(contours)
        for i, c in enumerate(contours):
            minRect[i] = cv2.minAreaRect(c)
            if c.shape[0] > 5:
                minEllipse[i] = cv2.fitEllipse(c)

        # draw contours
        for i, c in enumerate(contours):
        # for cnt in contours:
            cv2.drawContours(frame, [c], 0, (0, 0, 255), 2)
            # ellipse
            if c.shape[0] > 5:
                cv2.ellipse(frame, minEllipse[i], (0, 0, 255), 2)
            # rotated rectangle
            box = cv2.boxPoints(minRect[i])
            box = np.intp(box)  # np.intp: Integer used for indexing (same as C ssize_t; normally either int32 or int64)
            cv2.drawContours(frame, [box], 0, (0, 0, 255))
            # print(minRect[i])
        cv2.imshow("img", frame)
        cv2.imwrite("./frame/" + video_name + "/%d.jpg" % count, frame)  # save frame as JPEG file
        contoursAdd = []
        contoursArea = []
        for i in contours:
            M = cv2.moments(i)
            if M['m00'] != 0:
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                contoursAdd.append([count, cx, cy, M['m00']])
                contoursArea.append(M['m00'])

        if contoursArea:
            file_index = 300 + count*3
            filename = str(file_index) + '.jpg'
            if os.path.exists('D:\\tobii\\frame\\actualscreen\\'+ video_name + '\\' +filename) != True:
                break
            largest = max(contoursArea)
            max_index = contoursArea.index(largest)
            coordinate["id"] = [contoursAdd[max_index][0]]
            if contoursAdd[max_index][0] == 0:
                sec = 10
            else:
                sec = contoursAdd[max_index][0] / 30 + 10
            coordinate["sec"] = [round(sec,2)]

            coordinate["x"] = [contoursAdd[max_index][1]]
            coordinate["y"] = [contoursAdd[max_index][2]]
            if count_distance == 0:
                coordinate["coordinates_difference"] = ['NA']
                coordinate["mean_square_error"] = ['NA']
            else:
                current_cord = [contoursAdd[max_index][1],contoursAdd[max_index][2]]
                diff_distance = distance.minkowski(current_cord, previous_cord, 3)
                coordinate["coordinates_difference"] = [diff_distance]
                current_img = cv2.imread('D:\\tobii\\frame\\actualscreen\\'+ video_name + '\\' +filename)
                current_img = cv2.cvtColor(current_img, cv2.COLOR_BGR2GRAY)
                h, w = current_img.shape
                img_diff = cv2.subtract(current_img, previous_img)
                img_err = np.sum(img_diff**2)
                img_mse = img_err/(float(h*w))
                coordinate["mean_square_error"] = [img_mse]
            previous_cord = [contoursAdd[max_index][1],contoursAdd[max_index][2]]
            previous_img = cv2.imread('D:\\tobii\\frame\\actualscreen\\'+ video_name + '\\' +filename)
            previous_img = cv2.cvtColor(previous_img, cv2.COLOR_BGR2GRAY)
            count_distance += 1
            link = Path('D:\\tobii\\frame\\actualscreen\\'+ video_name + '\\' +filename).as_uri()
            coordinate["screen_path"] = [link]
            #coordinate["area"] = [contoursAdd[max_index][3]]

            summary = pd.concat([summary, coordinate])

        k = cv2.waitKey(30) & 0xff
        count += 1
        if k == 27:
            break

    summary.to_csv("./output/" + video_name + ".csv",index=False)

    bday = datetime.datetime.now()
    time_diff = bday - today
    print("The summary takes " + str(time_diff) + " seconds to generate. You can check in the filepath(output)")

actual_val = input("Enter your filename of the video with ACTUAL screen (including filetype): ")
print("The video name is "+ actual_val)
black_val = input("Enter your filename of the video with BLACK screen (including filetype): ")
print("The video name is "+ black_val)
sourceVideoToFrame_syncScreen('./video/'+ black_val, './frame/syncblackscreen/'+ black_val +'/')
sourceVideoToFrame_actualScreen('./video/'+ actual_val, './frame/actualscreen/' + actual_val +'/') 
x_coord, y_coord = getCoordFromActualScreen('./frame/actualscreen/' + actual_val + '/')
img_no = syncStartPoint(x_coord,y_coord,'./frame/syncblackscreen/' + black_val +'/')
sourceVideoToFrame_finalScreen(img_no,'./video/'+ black_val, './frame/blackscreen/'+ black_val +'/')
generateSummary(actual_val,'./frame/blackscreen/' + black_val +'/','./frame/actualscreen/' + actual_val +'/')